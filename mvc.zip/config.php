<?php
define("urlsite","http://localhost/mvc/");